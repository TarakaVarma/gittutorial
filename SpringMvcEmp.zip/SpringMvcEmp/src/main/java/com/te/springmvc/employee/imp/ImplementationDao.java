package com.te.springmvc.employee.imp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.stereotype.Component;

import com.te.springmvc.employee.Dto.EmployeeDto;
@Component
public class ImplementationDao {
	
	public boolean insert(EmployeeDto emp) {
		boolean insert =false;
		String url="jdbc:mysql://localhost:3306/user";
		String u="root";
		String p="root";
	    Connection c;
		try {
			Class.forName("com.mysql.jdbc.Driver"); 
			c = DriverManager.getConnection(url,u,p);
			PreparedStatement psp = c.prepareStatement("INSERT INTO emp(NAME,ID) values(?,?)");
			psp.setString(1,emp.getName() );
		      psp.setString(2,emp.getId() );
		      
		      psp.executeUpdate();
		      insert=true;
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return insert;
		
	}
	

}
