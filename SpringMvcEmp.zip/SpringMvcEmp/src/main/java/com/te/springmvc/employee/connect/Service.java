package com.te.springmvc.employee.connect;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.te.springmvc.employee.Dto.EmployeeDto;
import com.te.springmvc.employee.imp.ImplementationDao;
@Component
public class Service {
	@Autowired
	ImplementationDao da;
	
	public void addName(EmployeeDto emp){
		 da.insert(emp);
			 
	}

}
