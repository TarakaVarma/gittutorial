package com.te.springmvc.employee.Dto;

import java.io.Serializable;

import lombok.Data;
@Data
public class EmployeeDto  implements Serializable {

	private String name;
	private String id;
	
	
	
	
}
