package com.te.springmvc.employee.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.te.springmvc.employee.Dto.EmployeeDto;
import com.te.springmvc.employee.connect.Service;

@Controller
public class Employee{
	@Autowired
	Service sc;
    @GetMapping("/data")
	public String getData() {
		return  "Data";
		
	}
    @PostMapping("/get")
    public String display(EmployeeDto emp, ModelMap map, HttpServletRequest req) {
    	sc.addName(emp);
//    	emp.setId(req.getParameter("id"));
//    	emp.setName(req.getParameter("name"));
//    	     String  u  =(String)emp.getName();
//    	     String  i  =(String)emp.getId();
//    	     map.addAttribute("UNAME",u);
//    	     map.addAttribute("UID",i);
    	map.addAttribute("EMP",emp);
    	
		return "Display";
    	
    }
	
}
